export default function GrayBackground() {
  return <div className="bg-gray"></div>;
}
