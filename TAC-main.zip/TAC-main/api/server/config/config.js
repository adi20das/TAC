const mongoose = require('mongoose');
mongoose.set("strictQuery", false);
//  mongoose.connect("mongodb+srv://debobroto:debobroto@cluster0.hsydmt2.mongodb.net/?retryWrites=true&w=majority", {
//     useNewUrlParser:true,
// }
 mongoose.connect("mongodb+srv://Admin:tuOw1fQyjaUW9xyk@tacdatabase.bdthmew.mongodb.net/?retryWrites=true&w=majority", {
    useNewUrlParser:true,
}


);

